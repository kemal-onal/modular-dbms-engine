# CMPE 321 - Project 4

The Project 3 DBMS engine extended with **Write-Ahead Logging (WAL)** and a
**simplified ARIES crash-recovery manager**. The engine survives random process
kills and, on restart, rebuilds a consistent state automatically: committed
transactions are durable, uncommitted ones are rolled back.

Python 3 only, no third-party packages. Tested on 3.11+.

## Run

    python3 archive.py config.json input.txt

On startup `archive.py` runs three-phase recovery over `wal.log` before processing
the input file, so a previous run that ended in `crash` is repaired transparently.

Files written next to `archive.py`:

- `output.txt` - results of search / range_search / explain. Truncated each run.
- `log.csv` - one line per command, `unix_ts,command,success|failure`. Append-only.

Files written in the working directory (persist across runs):

- `wal.log` - the write-ahead log (owned by the recovery manager, never buffered).
- `master.log` - master record: last checkpoint LSN + next LSN.
- `<type>.bin`, `<type>_hash_idx.bin`, `<type>_bptree_idx.bin` - heap and index files.
- `_catalog_.bin` - system catalog. `<type>_free.bin` - heap free list.

## config.json

    {
      "page_size": 4096,
      "max_records_per_page": 10,
      "buffer_pool_size": 16,
      "replacement_policy": "LRU",
      "index_strategy": "bplus_tree",
      "checkpoint_interval": 50,
      "log_buffer_size": 8
    }

`replacement_policy` is `LRU` or `MRU`. `index_strategy` is `heap_scan`,
`hash_index`, or `bplus_tree`. `checkpoint_interval` is the number of operations
between fuzzy checkpoints; `log_buffer_size` is how many log records are held in RAM
before being flushed. Any layer can be swapped without touching the others.

## Commands

Project 4 makes all data operations explicitly transactional. A bare data command
outside an open transaction is invalid (logged as a failure, no effect on the DB).

    tx_begin <name>                 open a transaction (many may be open at once)
    tx_op <name> <data command>     run a data command inside <name>, logged under it
    tx_commit <name>                commit: write commit record, fsync, write end
    crash                           simulate power loss via os._exit(1)

Data commands (used as the body of `tx_op`):

    create type <name> <num_fields> <pk_order> <f1n> <f1t> ...
    create record <type> <v1> <v2> ...
    search record <type> <pk>
    delete record <type> <pk>
    range_search <type> <field> <low> <high>
    explain <any data command>
    stats / stats reset

Field types are `int` or `str`. PK is the field at position `pk_order` (1-indexed).
`range_search` is integer-field only; on `hash_index` it falls back to a heap scan.
Failures (duplicate type/PK, missing record/type, range on a non-int field, bad
syntax, data op outside a transaction) are logged with status `failure` and never
crash the engine.

## Recovery design

The recovery manager (`recovery_manager/`) is a cross-cutting component: the query
processor begins/commits transactions through it, the file/index manager logs page
updates through it before mutating a page, and the buffer manager forces the log
before writing any dirty page back.

- **WAL #1 (atomicity):** a dirty page is never written to disk before the log up to
  its `pageLSN` is on disk (`flush_log_up_to`).
- **WAL #2 (durability):** `tx_commit` does not return until the commit record is
  `fsync`-ed.
- **Logging:** every page change is logged with the full before/after page image;
  every `tx_op` additionally logs the logical command and its inverse.
- **Recovery (three phases, at startup):** *Analysis* rebuilds the transaction table
  and dirty-page table from the last checkpoint and classifies committed vs loser
  transactions; *Redo* replays update records in LSN order (repeat history), which is
  idempotent because each after-image is a whole-page snapshot; *Undo* rolls back
  loser transactions logically by re-executing the inverse of each of their
  operations, so changes other transactions made to the same page are preserved.
- **Checkpointing:** fuzzy checkpoints (every `checkpoint_interval` ops) snapshot the
  transaction and dirty-page tables and update the master record, bounding the log so
  repeated crash-restart cycles stay fast.

## Quick example

    tx_begin T1
    tx_op T1 create type book 4 1 title str author str year int copies int
    tx_op T1 create record book Dune Herbert 1965 100
    tx_commit T1
    tx_begin T2
    tx_op T2 create record book Neuromancer Gibson 1984 75
    crash

After restarting on the same data directory, `Dune` survives (T1 committed) and
`Neuromancer` is gone (T2 was a loser).

## Layout

    archive.py
    config.json
    disk_space_manager/__init__.py
    buffer_manager/__init__.py
    file_index_manager/__init__.py
    query_processor/__init__.py
    recovery_manager/__init__.py
    common/results.py

## Notes

The catalog and all data files persist, so schemas come back from `_catalog_.bin` on
the next run. Delete uses a slot bitmap tombstone; freed heap slots are not reused.
Hash uses 10 buckets and chains overflow pages. Delete the `*.bin`, `wal.log`, and
`master.log` files between unrelated runs for a clean state.
