# AI Usage

Tool: Claude. We used AI as an accelerator; the design decisions and the logic of the
code are ours, and we can explain every line. AI helped us work through the two issues
below.

## 1. Interleaved transactions vs. physical undo

**Problem:** When one of two interleaved transactions crashed and was rolled back in the
Undo phase, restoring the page to its old physical (byte) image also overwrote the data
of a committed (winner) transaction that had written to the same page (for example the
"Spirited" movie in the test case).

**Fix:** With AI we confirmed that without a locking mechanism (Strict 2PL), physical
undo is not safe on shared pages. We kept Redo physical (whole-page after-images
replayed in LSN order) but made Undo **logical**: each operation of a loser transaction
is reverted with its inverse command (create ↔ delete) through the engine, so a winner's
data on the same page is preserved.

## 2. range_search ordering mismatch

**Problem:** `range_search` returned the correct rows, but the output did not match the
`expected_output.txt` files byte-for-byte in the diff tests.

**Fix:** With AI's help we wrote a `sort(key=...)` that follows the spec's rule (sort by
the searched field first, break ties by primary key) so the results are written to the
file in exactly the required order.
